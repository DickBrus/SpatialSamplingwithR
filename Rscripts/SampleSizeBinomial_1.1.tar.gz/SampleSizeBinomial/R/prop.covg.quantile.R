prop.covg.quantile <-
function(prop.covg.out, worst.level)
{
  o <- order(prop.covg.out$out, decreasing=T)
  out <- prop.covg.out$out[o]
  f <- cumsum(prop.covg.out$f[o])
  w <- which(f>=worst.level)
  w <- ifelse(length(w)==0, length(out), min(w))
  return(out[w])
}
