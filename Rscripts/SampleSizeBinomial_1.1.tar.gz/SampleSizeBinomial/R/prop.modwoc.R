prop.modwoc <-
function(len, alpha, beta, level=0.95, exact=TRUE, sim.size=1000, precision=1e-6, mcs=3, worst.level=0.95)
{
  prop.prototype(len, alpha, beta, level=level, length.is.fixed=T, exact=exact, MBL=F, sim.size=sim.size, precision=precision, mcs=mcs, q=worst.level)
}
