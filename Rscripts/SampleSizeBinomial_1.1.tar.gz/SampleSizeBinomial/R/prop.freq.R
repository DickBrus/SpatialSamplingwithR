prop.freq <-
function(len, p.estimate, level=0.95)
{
  return(ceiling(4*qnorm((1+level)/2)^2*(p.estimate*(1-p.estimate))/len^2))
}
