prop.xSample.from.marginal <-
function(n, alpha, beta, sim.size)
{
  p <- rbeta(sim.size, alpha, beta)
  x <- table(rbinom(sim.size, n, p))
  f <- as.integer(x)/sim.size
  x <- as.integer(names(x))

  return(list(x=x, f=f))
}
