prop.freq0 <-
function(len, alpha, beta, level=0.95)
{
  return(prop.freq(len, alpha/(alpha+beta), level))
}
