prop.outcome <-
function(n, fixed.parm.target, alpha, beta, length.is.fixed=T, MBL=F, exact=T, sim.size=1000, precision=1e-6)
{
  # if (!is.loaded('OutcomeEstimation')) dyn.load('c:/users/pbelisle/My Documents/Home/SampleSize/SampleSizeBinomial/bin/prop1.dll')

  if (exact)
  {
    x <- integer(0)
    out <- double(n+1)
    fx <- out
    z <- .C('OutcomeEstimation', as.integer(n), as.double(fixed.parm.target), as.integer(length.is.fixed), as.integer(MBL), as.double(alpha), as.double(beta), as.integer(x), length(x), as.double(out), as.double(fx), as.double(precision))
    out <- list(out=z[[9]], f=z[[10]])
  }
  else
  {
    x <- prop.xSample.from.marginal(n, alpha, beta, sim.size)
    out <- double(length(x$x))
    z <- .C('OutcomeEstimation', as.integer(n), as.double(fixed.parm.target), as.integer(length.is.fixed), as.integer(MBL), as.double(alpha), as.double(beta), as.integer(x$x), length(x$x), as.double(out), as.double(x$f), as.double(precision))
    out <- list(out=z[[9]], f=x$f)
  }

  return(out)
}



