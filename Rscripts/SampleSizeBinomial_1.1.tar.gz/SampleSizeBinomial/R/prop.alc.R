prop.alc <-
function(len, alpha, beta, level=0.95, exact=TRUE, sim.size=1000, precision=1e-6, mcs=3)
{
  prop.prototype(len, alpha, beta, level=level, length.is.fixed=F, exact=exact, MBL=F, sim.size=sim.size, precision=precision, mcs=mcs)
}
