setGeneric(
    name = "getObjectiveFunctionValue",
    def = function(object, ...) {
        standardGeneric("getObjectiveFunctionValue")
    }
)
