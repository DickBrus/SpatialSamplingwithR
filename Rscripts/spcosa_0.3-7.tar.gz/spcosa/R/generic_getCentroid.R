setGeneric(
    name = "getCentroid",
    def = function(object, ...) {
        standardGeneric("getCentroid")
    }
)
