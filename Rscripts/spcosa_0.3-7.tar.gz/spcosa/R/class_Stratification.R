setClass(
    Class = "Stratification",
    contains = "VIRTUAL"
)
