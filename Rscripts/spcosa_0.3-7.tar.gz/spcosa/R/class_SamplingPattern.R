setClass(
    Class = "SamplingPattern",
    representation = representation(
        sample = "SpatialPoints"
    )
)
