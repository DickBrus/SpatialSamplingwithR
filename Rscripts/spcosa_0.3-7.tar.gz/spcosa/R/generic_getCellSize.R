setGeneric(
    name = "getCellSize",
    def = function(object, ...) {
        standardGeneric("getCellSize")
    }
)
