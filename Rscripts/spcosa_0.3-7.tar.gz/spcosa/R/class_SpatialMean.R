setClass(
    Class = "SpatialMean",
    prototype = prototype(
        description = "Spatial mean"
    ),
    contains = "Statistic"
)
