setClass(
    Class = "SamplingPatternPurposive",
    contains = "SamplingPattern"
)
