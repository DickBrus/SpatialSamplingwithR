setClass(
    Class = "Statistic",
    representation = representation(
        description = "character"
    ),
    contains = "VIRTUAL"
)
