setClass(
    Class = "SamplingPatternRandom",
    contains = "SamplingPattern"
)
