setClass(
    Class = "CompactStratificationPriorPoints",
    representation = representation(
        priorPoints = "SpatialPoints"
    ),
    contains = "CompactStratification"
)
