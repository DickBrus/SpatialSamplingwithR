setGeneric(
    name = "getSampleSize",
    def = function(object, ...) {
        standardGeneric("getSampleSize")
    }
)
