setClass(
    Class = "SamplingPatternPriorPoints",
    representation = representation(
        isPriorPoint = "logical"
    ),
    contains = "SamplingPatternPurposive"
)
