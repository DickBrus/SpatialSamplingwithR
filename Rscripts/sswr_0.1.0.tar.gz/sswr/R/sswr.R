#' Spatial Sampling with R
#'
#' Data sets for the book Spatial Sampling with R
#'
#' # Available data sets:
#'
#' * [grdVoorst]: Soil organic matter in voorst (The Netherlands).
#' * [grdKandahar]: Poppy fields in Kandahar (Afghanistan).
#' * [grdAmazonia]: Aboveground biomass in Eastern Amazonia (Brazil).
#' * [grdSpainPortugal]: Annual mean air temperature in Spain and Portugal
#' * [grdHunterValley]: Terrain attributes for Hunter Valley (Australia)
#' * [grdXuancheng]: Terrain and climate attributes for Xuancheng (China)
#' * [sampleXuancheng]: Organic matter concentration in Xuancheng (China)
#' * [strataXuancheng]: Strata information for Xuancheng (China)
#' * [sampleAmhara]: Soil organic matter West Amhara (Ethiopa)
#' * [sampleCRF]: Soil electrical conductivity and electromagnetic induction
#'      (Uzbekistan)
#' * [transectsCRF]: Electromagnetic Induction Measurements Along Transects
#'      (Uzbekistan)
#' * [sampleLeest]: Nitrate-N data for Leest (Belgium)
#' * [sampleMelle]: Nitrate-N data for Melle (Belgium)
#'
#' @references Brus, Dick. 2021. Spatial sampling with R. The R Series.
#'   CRC Press.
#'
#' @docType package
#' @name sswr
NULL


