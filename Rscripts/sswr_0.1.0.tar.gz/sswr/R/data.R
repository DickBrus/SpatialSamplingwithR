#' Simulated Soil Organic Matter Concentration in Voorst (The Netherlands)
#'
#' Simulated data on a 25 m x 25 grid of the organic matter concentration
#' (g/kg) in the topsoil of an 6 km x 1 km area in the Netherlands.
#'
#' @format A data frame with `r nrow(grdVoorst)` rows and
#'   `r ncol(grdVoorst)` columns:
#' \describe{
#'   \item{stratum}{five combinations of soil type and land use classes.
#'   The first letter stands for the soil type: B for beekeerdgrond (sandy
#'   wetland soil with gleyic properties), E for enkeerdgrond (sandy soil with
#'   thick anthropogenic humic topsoil), P for podzols (sandy soil with
#'   eluviated horizon below the topsoil), R for river clay soil,
#'   and X for sandy soils. The second letter is for land use: A for agriculture
#'   (grassland, arable land), and F for forest.}
#'   \item{s1}{Easting (m)}
#'   \item{s2}{Northing (m)}
#'   \item{z}{Simulated Soil Organic Matter Concentration (g/kg)}
#' }
"grdVoorst"



#' Poppy Area in the Province of Kandahar (Afghanistan)
#'
#' Simulated data of poppy area (ha) per 5 km square in the province of Kandahar
#' (Afghanistan).
#'
#' @format A data frame with `r nrow(grdKandahar)` rows and
#'   `r ncol(grdKandahar)` columns:
#' \describe{
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{agri}{agricultural area (ha) per 5 km square.}
#'   \item{poppy}{poppy area (ha) per 5 km square.}
#' }
"grdKandahar"



#' Aboveground Live Woody Biomass (Eastern Amazonia)
#'
#' Aboveground live woody biomass (AGB) in megatons per ha
#' (Baccini et al., 2012) in a rectangular area of 1,642 km x 928 km in Eastern
#' Amazonia (Brazil). The data of Baccini et al. (2012) were aggregated to a map
#' with a resolution of 1 km x 1 km.
#'
#' @format A data frame with `r nrow(grdAmazonia)` rows and
#'   `r ncol(grdAmazonia)` columns:
#' \describe{
#'   \item{AGB}{aboveground live woody biomass (megatons per ha).}
#'   \item{SWIR2}{long term mean of MODIS short-wave infrared radiation.}
#'   \item{Terra_PP}{primary production (kg C/m2).}
#'   \item{Prec_dm}{average precipitation in driest month (mm).}
#'   \item{Elevation}{elevation (m).}
#'   \item{Clay}{clay content (g/kg).}
#'   \item{x1}{Easting (m).}
#'   \item{x2}{Northing (m).}
#'   \item{Biome}{four biomes.}
#'   \item{Ecoregion}{sixteen ecoregions.}
#' }
#'
#' @references Baccini, A., S. J. Goetz, W. S. Walker, N. T. Laporte, M. Sun,
#'   D. Sulla-Menashe, J. Hackler, P. S. A. Beck, R. Dubayah, M.A. Friedl,
#'   S. Samanta and R. A. Houghton (2012). Estimated carbon dioxide emissions
#'   from tropical deforestation improved by carbon-density maps.
#'   Nature Climate Change, 2(3):182–185.
"grdAmazonia"



#' Annual Mean Air Temperature in Spain and Portugal
#'
#' Annual mean air temperature at two metres above the earth surface (TAS) in
#' degrees C, in Spain and Portugal (islands excluded) for the years 2004, 2009,
#' 2014, and 2019. These data are part of the CHELSA data set
#' (Karger et al. 2017). The resolution of the grid is about 780 m x 780 m.
#'
#' @format A data frame with `r nrow(grdSpainPortugal)` rows and
#'   `r ncol(grdSpainPortugal)` columns:
#' \describe{
#'   \item{x}{Easting (m).}
#'   \item{y}{Northing (m).}
#'   \item{TAS2004}{Annual mean air temperature in 2004 (degrees Celsius).}
#'   \item{TAS2009}{Annual mean air temperature in 2009 (degrees Celsius).}
#'   \item{TAS2014}{Annual mean air temperature in 2014 (degrees Celsius).}
#'   \item{TAS2019}{Annual mean air temperature in 2019 (degrees Celsius).}
#' }
#'
#' @references Karger, D. N. et al. 2017. Climatologies at high resolution for
#'   the earth’s land surface areas. Sci. Data 4:170122
#'   doi: 10.1038/sdata.2017.122.
"grdSpainPortugal"


#' Terrain Attributes for Hunter Valley (Australia)
#'
#' Data frame of five terrain attributes for Hunter Valley.
#'
#' @format A data frame with `r nrow(grdHunterValley)` rows and
#'   `r ncol(grdHunterValley)` columns:
#'
#' \describe{
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{elevation_m}{elevation (m).}
#'   \item{slope_deg}{slope (degrees).}
#'   \item{cos_aspect}{cosine of aspect.}
#'   \item{cti}{compound topographic index.}
#'   \item{ndvi}{normalised difference vegetation index.}
#'   \item{landuse_class}{Native forest, Other, Pasture, and Viticulture.}
#'   \item{soil_landscape_unit}{3 Ways, Branxton, Mt View, Ogilvie, Pokolbin.}
#' }
#'
#' The resolution of the grid is 25 m x 25 m.
"grdHunterValley"



#' Terrain Attributes and Climate Variables in Xuancheng (China)
#'
#' Five terrain attributes and two climate variables in Xuancheng (Anhui
#' province, China).
#'
#' @format A data frame with `r nrow(grdXuancheng)` rows and
#'   `r ncol(grdXuancheng)` columns:
#' \describe{
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{plan.curvature}{planar curvature.}
#'   \item{profile.curvature}{profile curvature.}
#'   \item{slope}{slope (degrees).}
#'   \item{temperature}{temperature.}
#'   \item{precipitation}{precipitation.}
#'   \item{twi}{topographic wetness index.}
#'   \item{dem}{elevation (m).}
#'   \item{SOM_RF}{predictions of the organic matter concentration (g/kg) in
#'     the A horizon of the soil, obtained by random forest.}
#'   \item{SOM_KED}{predictions of the organic matter concentration (g/kg) in
#'     the A horizon of the soil, obtained by kriging with an external drift}
#'   \item{crfstrata}{stratum code (1-5)}
#' }
"grdXuancheng"



#' Organic Matter Concentration by Three Sampling Designs in Xuancheng (China)
#'
#' Data of the organic matter concentration (g/kg) in the A horizon
#' of the soil at 183 points in Xuancheng
#' (Anhui province, China). The data are collected by three sampling designs,
#' indicated in the column \code{sample} of the data frame: a square grid (grid),
#' sampling tailored at mapping with the individual predictive soil mapping
#' method (iPSM), and stratified simple random sampling (STSI).
#'
#' @format A data frame with `r nrow(sampleXuancheng)` rows and
#'   `r ncol(sampleXuancheng)` columns:
#' \describe{
#'   \item{ID}{identifier.}
#'   \item{original_I}{identifier.}
#'   \item{SOM_A_hori}{organic matter concentration (g/kg) in the A horizon.}
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{plan.curvature}{planar curvature.}
#'   \item{profile.curvature}{profile curvature.}
#'   \item{slope}{slope (degrees).}
#'   \item{temperature}{temperature.}
#'   \item{precipitation}{precipitation.}
#'   \item{twi}{topographic wetness index.}
#'   \item{dem}{elevation (m).}
#'   \item{sample}{sampling design: grid, iPSM, or STSI.}
#'   \item{stratum}{strata used in STSI}
#' }
#'
#' @seealso \code{\link{strataXuancheng}}
"sampleXuancheng"



#' Strata Information for Xuancheng (China)
#'
#' Size (number of raster cells, \code{N_h}) of the eight strata (units of a
#' geological map) used to collect the stratified simple random sample data in
#' \code{\link{sampleXuancheng}}.
#'
#' @format A data frame with `r nrow(sampleXuancheng)` rows and
#'   `r ncol(sampleXuancheng)` columns:
#' \describe{
#'   \item{stratum}{units of a geological map.}
#'   \item{N_h}{stratum size (number of raster cells).}
#' }
#'
#' @seealso \code{\link{sampleXuancheng}}
"strataXuancheng"



#' Soil Organic Matter West Amhara (Ethiopa)
#'
#' Convenience sample of measurements of organic matter concentration in dag/kg
#' in the topsoil at 407 points (SOM), mainly along roads, in West Amhara
#' (Ethiopia). Besides, several auxiliary variables are in the data.frame.
#'  are in the data frame.
#'
#' @format A data frame with `r nrow(sampleAmhara)` rows and
#'   `r ncol(sampleAmhara)` columns:
#' \describe{
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{SOM}{organic matter concentration in dag/kg in the topsoil.}
#'   \item{soil}{soil type.}
#'   \item{dem}{elevation (m).}
#'   \item{twi}{topographic wetness index.}
#'   \item{slope}{slope.}
#'   \item{evi}{enhanced vegetation index.}
#'   \item{aspect}{aspect.}
#'   \item{rfl_MIR}{ mid-infrared reflectance.}
#'   \item{rfl_NIR}{near-infrared reflectance.}
#'   \item{rfl_red}{red reflectance.}
#'   \item{lst}{land surface temperature.}
#'   \item{lst_night}{land surface temperature in the night.}
#' }
"sampleAmhara"



#' Soil Electrical Conductivity and Electromagnetic Induction (Uzbekistan)
#'
#' Data of the electrical conductivity until a depth of 150 cm (ECe150) and of
#' the electromagnetic induction in vertical dipole mode with transmitter at
#' 1 m (EMv1m) at 142 points in the Cotton Research Farm in Uzbekistan.
#' The data have been collected in eight surveys in the period 2008-2011. The
#' date is the column date, and the period is the column survey.
#'
#' @format A data frame with `r nrow(sampleCRF)` rows and
#'   `r ncol(sampleCRF)` columns:
#' \describe{
#'   \item{nn}{identifier}
#'   \item{point}{point identifier}
#'   \item{x}{Easting (m).}
#'   \item{y}{Northing (m).}
#'   \item{date}{date.}
#'   \item{field}{field identifier.}
#'   \item{ECe30}{electrical conductivity 30 cm.}
#'   \item{ECe60}{electrical conductivity 60 cm.}
#'   \item{ECe90}{electrical conductivity 90 cm.}
#'   \item{ECe120}{electrical conductivity 120 cm.}
#'   \item{ECe150}{electrical conductivity 150 cm.}
#'   \item{EMv1m}{electromagnetic induction (vertical dipole mode, 1m).}
#'   \item{EMh1m}{electromagnetic induction (horizontal dipole mode, 1m).}
#'   \item{EMv05m}{electromagnetic induction (vertical dipole mode, 0.5m).}
#'   \item{EMh05m}{electromagnetic induction (horizontal dipole mode, 0.5m).}
#'   \item{Period}{period}
#'   \item{t}{t}
#' }
"sampleCRF"



#' Electromagnetic Induction Measurements Along Transects (Uzbekistan)
#'
#' Electromagnetic induction measurements (mS/m) of the apparent electrical
#' conductivity on the 80 ha Cotton Research Farm in Uzbekistan. The data are on
#' transects covering the Cotton Research Farm (16,068 points in total). The
#' EM-measurements have been done in vertical dipole mode, with the transmitter
#' at 1 m (EMv1mt) and 0.5 m (EMv05mt) from the receiver.
#'
#' @format A data frame with `r nrow(transectsCRF)` rows and
#'   `r ncol(transectsCRF)` columns:
#' \describe{
#'   \item{x}{Easting (m).}
#'   \item{y}{Northing (m).}
#'   \item{date}{date.}
#'   \item{time}{time.}
#'   \item{EMv1m}{electromagnetic induction (vertical dipole mode, 1m).}
#'   \item{EMv05m}{electromagnetic induction (vertical dipole mode, 0.5m).}
#'   \item{t}{t}
#'   \item{EMv1mt}{electromagnetic induction (vertical dipole mode,
#'     transmitter at 1m).}
#'   \item{EMv05mt}{electromagnetic induction (vertical dipole mode,
#'     transmitter at 0.5m).}
#'   \item{field}{}
#' }
"transectsCRF"



#' Nitrate-N data for Leest (Belgium)
#'
#' Nitrate-N (NO3-N) in kg/ha in the soil layer 0-90 cm, using a standard soil
#' density of 1,500 kg/m3, at 30 points in an agricultural field in Leest
#' (Belgium).
#'
#' @format A data frame with `r nrow(sampleLeest)` rows and
#'   `r ncol(sampleLeest)` columns:
#' \describe{
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{N}{Nitrate-N (NO3-N) in kg/ha in the soil layer 0-90 cm.}
#' }
"sampleLeest"



#' Nitrate-N data for Melle (Belgium)
#'
#' Nitrate-N (NO3-N) in kg/ha in the soil layer 0-90 cm, using a standard soil
#' density of 1,500 kg/m3, at 30 points in an agricultural field in Melle
#' (Belgium).
#'
#' @format A data frame with `r nrow(sampleMelle)` rows and
#'   `r ncol(sampleMelle)` columns:
#' \describe{
#'   \item{s1}{Easting (m).}
#'   \item{s2}{Northing (m).}
#'   \item{N}{Nitrate-N (NO3-N) in kg/ha in the soil layer 0-90 cm.}
#' }
"sampleMelle"
